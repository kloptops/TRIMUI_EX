# This ann_module isn't for test_typing,
# it's for test_module

a:int=3
b:str=4
